let countriesData = {};
let selectedCountry = null;
let selectedCity = null;

const todayISO = new Date().toISOString().split('T')[0];

const countryListDiv = document.getElementById("country-list");
const cityListDiv = document.getElementById("city-list");
const citySection = document.getElementById("city-section");
const dateSection = document.getElementById("date-section");
const startDateInput = document.getElementById("start-date");
const endDateInput = document.getElementById("end-date");
const submitBtn = document.getElementById("submit-btn");
const resultDiv = document.getElementById("result");

startDateInput.min = todayISO;
endDateInput.min = todayISO;

// CSV → JSON 변환 함수
function csvToJson(csv) {
  const lines = csv.trim().split('\n');
  const data = {};
  for (let i = 1; i < lines.length; i++) {
    const [country, city] = lines[i].split(',').map(v => v.trim());
    if (!data[country]) data[country] = [];
    if (city && !data[country].includes(city)) data[country].push(city);
  }
  return data;
}

// CSV 파일 로드
fetch('countries_cities.csv')
  .then(res => res.text())
  .then(csvText => {
    countriesData = csvToJson(csvText);
    renderCountryButtons();
  })
  .catch(err => {
    countryListDiv.textContent = "데이터를 불러오는 중 오류가 발생했습니다.";
    console.error(err);
  });

// 국가 버튼 렌더링
function renderCountryButtons() {
  countryListDiv.innerHTML = "";
  Object.keys(countriesData).forEach(country => {
    const btn = document.createElement("button");
    btn.className = "select-btn";
    btn.textContent = country;
    btn.addEventListener("click", () => {
      selectedCountry = country;
      selectedCity = null;
      highlightSelectedButton(countryListDiv, btn);
      renderCityButtons(country);
      citySection.style.display = "block";
      dateSection.style.display = "none";
      submitBtn.disabled = true;
      resultDiv.innerHTML = "";
    });
    countryListDiv.appendChild(btn);
  });
}

// 도시 버튼 렌더링
function renderCityButtons(country) {
  cityListDiv.innerHTML = "";
  countriesData[country].forEach(city => {
    const btn = document.createElement("button");
    btn.className = "select-btn";
    btn.textContent = city;
    btn.addEventListener("click", () => {
      selectedCity = city;
      highlightSelectedButton(cityListDiv, btn);
      dateSection.style.display = "block";
      submitBtn.disabled = true;
      resultDiv.innerHTML = "";
    });
    cityListDiv.appendChild(btn);
  });
}

// 선택된 버튼 하이라이트
function highlightSelectedButton(container, selectedBtn) {
  Array.from(container.children).forEach(btn => btn.classList.remove("selected"));
  selectedBtn.classList.add("selected");
}

// 날짜 입력 체크 및 제출 버튼 활성화
startDateInput.addEventListener("change", () => {
  const start = startDateInput.value;
  if (start) {
    endDateInput.min = start;
    if (endDateInput.value && endDateInput.value < start) {
      endDateInput.value = "";
    }
  }
  checkSubmitReady();
});

endDateInput.addEventListener("change", checkSubmitReady);

function checkSubmitReady() {
  submitBtn.disabled = !(selectedCountry && selectedCity && startDateInput.value && endDateInput.value);
  resultDiv.innerHTML = "";
}

// 여행 기간 계산
function calculateTripDuration(start, end) {
  const startDate = new Date(start);
  const endDate = new Date(end);
  const diffTime = endDate - startDate;
  const days = diffTime / (1000 * 60 * 60 * 24);
  return {
    days: days + 1,
    nights: days
  };
}

// 제출 버튼 클릭 시 API 호출
submitBtn.addEventListener("click", () => {
  const start = startDateInput.value;
  const end = endDateInput.value;

  if (!selectedCountry || !selectedCity || !start || !end) {
    alert("모든 항목을 선택해 주세요.");
    return;
  }

  const { days, nights } = calculateTripDuration(start, end);

  const requestBody = {
    country: selectedCountry,
    city: selectedCity,
    start_date: start,
    end_date: end
  };

  submitBtn.disabled = true;
  submitBtn.textContent = "여행 일정 생성 중...";
  resultDiv.textContent = "";

  fetch("http://127.0.0.1:8000/generate-itinerary", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(requestBody)
  })
    .then(response => response.json())
    .then(data => {
      if (data.itinerary) {
        resultDiv.textContent = data.itinerary;
      } else if (data.error) {
        resultDiv.textContent = "오류 발생: " + data.error;
      } else {
        resultDiv.textContent = "알 수 없는 오류가 발생했습니다.";
      }
    })
    .catch(err => {
      console.error(err);
      resultDiv.textContent = "서버와 통신하는 중 오류가 발생했습니다.";
    })
    .finally(() => {
      submitBtn.disabled = false;
      submitBtn.textContent = "여행 계획 제출";
    });
});
