import os
import torch
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from transformers import AutoTokenizer, AutoModelForCausalLM
import uvicorn

os.environ['HF_TOKEN'] = ""

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

model_name = "LGAI-EXAONE/EXAONE-3.5-2.4B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(
    model_name,
    trust_remote_code=True
)

model = AutoModelForCausalLM.from_pretrained(
    model_name,
    torch_dtype=torch.float16,
    trust_remote_code=True,
    device_map="auto"
)

class TravelInfo(BaseModel):
    country: str
    city: str
    start_date: str
    end_date: str

def clean_response(prompt: str, decoded_output: str) -> str:
    response = decoded_output.replace(prompt, "").strip()
    if response.startswith("요."):
        response = response[2:].strip()
    if response.startswith("-"):
        response = response[1:].strip()
    return response

def generate_itinerary(prompt: str) -> str:
    inputs = tokenizer(prompt, return_tensors="pt")
    inputs = {k: v.to(model.device) for k, v in inputs.items()}
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_length=1024,
            pad_token_id=tokenizer.eos_token_id,
            repetition_penalty=1.2,
            no_repeat_ngram_size=3,
            temperature=0.7,
            top_p=0.9
        )
    decoded = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return clean_response(prompt, decoded)

@app.get("/")
async def root():
    return {"message": "EXAONE 여행 일정 생성기 작동 중"}

@app.post("/generate-itinerary")
async def create_itinerary(info: TravelInfo):
    prompt = (
        f"나는 {info.start_date}부터 {info.end_date}까지 {info.country} {info.city}로 여행을 갈 거야. "
        f"하루 단위로 상세한 여행 일정을 추천해줘. 장소, 활동 등을 포함해서 알려줘."
    )
    print("생성 요청 프롬프트:", prompt)
    try:
        result = generate_itinerary(prompt)
        return {"itinerary": result}
    except Exception as e:
        return {"error": str(e)}

if __name__ == '__main__':
    uvicorn.run(app, host='0.0.0.0', port=8000)
